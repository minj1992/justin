"""
setup_bigtable_tables.py

One-time setup: creates the 2 destination Bigtable tables (if they don't
already exist) with the 'data' column family required by
build_obligation_pipeline.py. Run this once before running the pipeline
with --mode=bigtable.

Requires: pip install 'apache-beam[gcp]' --break-system-packages
(this also installs google-cloud-bigtable, which this script uses directly)

Usage:
    python3 setup_bigtable_tables.py \
        --project=us-gcp-ame-con-ff12d-npd-1 \
        --instance=afs-poc-bigtable \
        --table_full=obligations_full \
        --table_essential=obligations_essential
"""
import argparse

from google.cloud import bigtable


def ensure_table_with_column_family(instance, table_name, column_family_id="data"):
    table = instance.table(table_name)
    if not table.exists():
        table.create()
        print(f"Created table: {table_name}")
    else:
        print(f"Table already exists: {table_name}")

    existing_families = table.list_column_families()
    if column_family_id not in existing_families:
        cf = table.column_family(column_family_id)
        cf.create()
        print(f"  Created column family '{column_family_id}' on {table_name}")
    else:
        print(f"  Column family '{column_family_id}' already exists on {table_name}")


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True)
    parser.add_argument("--instance", required=True)
    parser.add_argument("--table_full", default="obligations_full")
    parser.add_argument("--table_essential", default="obligations_essential")
    args = parser.parse_args()

    client = bigtable.Client(project=args.project, admin=True)
    instance = client.instance(args.instance)

    for table_name in (args.table_full, args.table_essential):
        ensure_table_with_column_family(instance, table_name)

    print("Done.")


if __name__ == "__main__":
    run()

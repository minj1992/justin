# Our pipeline vs. Imaan's pipeline — and why the design moved to "full visualization"

This note answers the three things asked: why the design changed to the
consolidated Table A/B view, what's actually different between the two
codebases, and what this pass changed in Imaan's code (full detail in
`CHANGELOG.md`).

## 1. Why "full visualization" — the Table A (full) / Table B (essential) model

Our original POC (`pipeline_full11_corrected.py`) writes **11 separate
Bigtable tables**, one per source topic (TBOBLIGR, TBCUROBL, TBOBLHST,
TBFUTOBL, account_relationships, etc.), each holding only that topic's raw
fields plus padded obligor/obligation keys. To see one loan's whole picture
you have to query all 11 tables and stitch the rows together yourself.

Imaan's design collapses that into **2 tables**:
- **Table A ("full")** — every sourced + calculated field for an obligation,
  one row per obligation.
- **Table B ("essential")** — the subset of fields AFS Vision actually
  consumes, same row key.

Why this is the right call for the demo, based on the transcript and the
lineage sheet:
- The client doesn't care how many Bigtable tables exist underneath — that's
  an implementation detail. What they're evaluating is whether the
  **BOL→OBL→Topic→AFS transformation and the 6 calculated fields
  (CURR_PRIN_BAL_AMT, CURR_LINE_AMT, LOAN_LINE_TYPE, BALANCE,
  INTEREST_PAID_YTD, INT_PAYMENT_DATE)** come out correct per the Business
  Rules–Cal fields sheet.
- With 11 raw tables, a single loan's record is scattered and partially
  null in each table (a TBCUROBL-only loan has nulls in the TBOBLHST table,
  etc.) — that reads as broken even when it isn't. One consolidated row per
  obligation is "neater and more well populated" and lets you eyeball a
  single row against the sheet's expected values directly.
- It also forces the business-rule logic (loan/line resolution, takedown-chain
  walk, balance calc) to actually be implemented and testable in one place,
  rather than deferred to "whoever joins the 11 tables later." That's why
  Imaan's code has all the calculation logic ours doesn't yet.

Net: the full-visualization model is a **presentation/validation choice for
the demo**, not a claim that production Bigtable has to look like this —
our streaming/11-table design and Imaan's batch/2-table design aren't
mutually exclusive; they're testing different layers (raw dual-write
plumbing vs. business-rule correctness).

## 2. Our code vs. Imaan's code — the actual differences

| | **Ours** (`pipeline_full11_corrected.py`) | **Imaan's** (`build_obligation_pipeline.py`) |
|---|---|---|
| **Goal proven** | The *plumbing*: can we move every topic's rows from source to Bigtable **and** AlloyDB reliably, in both batch and streaming? | The *business logic*: do the 6 calculated AFS fields come out right per the lineage sheet? |
| **Ingestion** | GCS (batch) **or** Pub/Sub (streaming) → Dataflow, switchable via `--project_for_subs` | Local/GCS files → Dataflow, batch only (no streaming path yet) |
| **Sinks** | Dual write: **Bigtable + AlloyDB** (`WriteToAlloyDB` DoFn with schema auto-discovery + upsert), feeding BigQuery downstream | **Bigtable only** — no AlloyDB/relational sink |
| **Tables** | 11 separate tables, 1:1 with source topics, each keyed `OBLIGOR_NUMBER#OBLIGATION_NUMBER` | 2 tables: Table A (full) / Table B (essential), same row key, 1 row per obligation combining all topics |
| **Transformation** | ID zero-padding only (`clean_and_pad`) — raw topic fields pass through otherwise | Full Column C logic: `left_pad`, `substring_fn`, `case_boolean`, `iso_timestamp_minus_5`, `signed_tran_amount`, plus all 6 calculated fields |
| **Loan/Line resolution** | Not implemented | `resolve_loan_line()` — 5th-char processTypeCode check, accountStatusCode fallback, up-to-5-hop takedown-chain walk via relationship/supplemental join |
| **Balance / interest calcs** | Not implemented | `calc_balance`, `calc_interest_paid_ytd`, `calc_int_payment_date`, `compute_obligor_totals` |
| **Online-banking eligibility filter** | Not implemented | `is_online_banking_eligible()` |
| **Row ordering / determinism** | N/A (no multi-record selection logic yet) | Was the source of the "wonky balance" bug — fixed this pass (see below) |
| **Schema flexibility** | AlloyDB side auto-discovers destination columns, case/snake_case-insensitive | Fixed JSON schema per table, no relational sink |
| **State** | Already working end-to-end (batch + streaming, dual sink) | Was already working for the happy-path scenarios; this pass fixed the two live bugs Imaan flagged |

In short: **ours proves the pipe works, Imaan's proves the water coming out
of it is correct.** Neither one is wrong — they were built to answer
different questions, which is exactly why "whatever's missing on one side,
we add" is the right next step rather than picking one and discarding the
other. The obvious next merge step (not done yet, flagged for discussion):
port Imaan's calculated-field logic into a 12th/consolidated write inside
our dual-write pipeline so the streaming path also produces Table A/B into
Bigtable *and* AlloyDB.

## 3. What was actually fixed in Imaan's code this pass

Full detail and verification steps are in `CHANGELOG.md`. Short version,
tied to what Imaan said live in the meeting:

- **"Some of the loan line types come in as null"** → root cause confirmed
  as an exact-string join that breaks on cross-topic zero-padding mismatches
  (his own write-up had already flagged this as ISSUE 3, "format
  unconfirmed"). Fixed with `FuzzyIndex` / `_lookup_lcm()`: tries the exact
  key first (every existing scenario still produces byte-identical output),
  falls back to a normalized key only on a miss.
- **"Balance amounts are a little weird... not sure if they should be
  negative"** → root cause confirmed as non-deterministic "first item in an
  unordered list" selection (`posted_txn_recs[0]`, unsorted balance-header
  scan) — the write-up itself calls this out under ISSUE 1 as not
  guaranteed stable between runs. Fixed by sorting deterministically by
  timestamp/sequence number before picking. The actual balance **formula**
  was re-checked against the lineage sheet and was already correct — this
  was a selection bug, not a math bug.
- Also closed two smaller documented gaps while in there: `SEQUENCE_NUMBER`
  is now populated (ISSUE 2), and `productCode` 15/16 exclusion (ISSUE 4) is
  now a one-line switch (`PRODUCT_CODE_FIELD`) instead of a silent no-op —
  confirmed against all 5 tabs of the lineage sheet that no field is
  currently sourced for it, so it's left off by default rather than guessed.
- **Deliberately not touched**: ISSUE 1's full redesign (one row per
  transaction instead of one per obligation), and ISSUE 5/6/7/8 — which
  process-type list is authoritative, the INTEREST_PAID_YTD year filter,
  INT_PAYMENT_DATE's output format, and the differing null defaults across
  legacy interfaces. All four are business/data-owner questions in Imaan's
  own write-up, not something to guess at in code.
- All fixes verified against the write-up's own Section 8 expected values —
  all 9 scenarios × 3 copies (57 rows) still match exactly, so nothing that
  was already correct was disturbed.

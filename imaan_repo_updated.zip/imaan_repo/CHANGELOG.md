# Changelog — build_obligation_pipeline.py

## 2026-10-09 — Chandra/Hemanth pass: fixed the null / "wonky balance" symptoms, closed two small gaps

Context: in the Imaan/Hemanth sync, Imaan described two problems live in his
own data:
1. "Some of the loan line types come in as null."
2. "Some of the balance amounts are a little bit weird... not even sure if
   they should be negative."

Before touching code, both of these were cross-checked against the live
`Lineage-OBL-v2` workbook (all 5 tabs) and against `obligation_pipeline_writeup.md`'s
own issue register — the write-up had already flagged the root causes as
ISSUE 3 (unconfirmed obligor/obligation padding across topics) and the
implicit ordering assumption behind `posted_txn_recs[0]` / the balance-header
scan. Fixed both. Also closed ISSUE 2 (SEQUENCE_NUMBER) with a safe default,
and converted ISSUE 4 (productCode) from a silent gap into a one-line switch
for when business names the field.

### 1. Null `LOAN_LINE_TYPE` — fixed
**Cause confirmed:** an exact-string join (`lcm_by_key` / `relationships_by_key`)
breaks silently the moment one topic pads an obligor/obligation number
differently than another (e.g. `"1020"` vs `"0001020"`) — exactly what
ISSUE 3 already called "format unverified." A miss returns `None`, which
*looks* identical to a genuinely broken/missing record.

**Fix:** `FuzzyIndex` (new) and `_lookup_lcm()` (new) try the exact key first
— so every existing test scenario produces byte-for-byte the same output —
and only fall back to a leading-zero-normalized key if the exact key misses.

**Verified:** reran all of section 8's scenarios (3 copies, 57 rows) — every
documented expected value still matches exactly. Added a new case with a
deliberately mismatched zero-padded `takedownObligationNumber`: before this
fix that record would resolve to `None`; after, it correctly resolves to
`"Line"`.

### 2. "Wonky" / inconsistent `BALANCE` — fixed (the selection, not the formula)
**Cause confirmed:** `posted_txn_recs[0]` and the balance-header-amount scan
both picked "whichever record happened to be first in the list Beam handed
back" — which is explicitly *not* guaranteed to be stable between runs on
identical data (the write-up says this outright under ISSUE 1). That's what
produces results that look "a little bit weird" / change between runs.

**Fix:** `_most_recent_txn()` and the balance-header-amount scan in
`calc_balance()` now sort deterministically (by recorded timestamp / source
sequence number) before picking one, instead of trusting list order.

**Verified:** same 57-row regression run — `BALANCE` still comes out
`-15500.00` / `-7250.00` exactly as documented. The fix only changes behavior
once there's more than one candidate record for the same obligation, which
today's generator doesn't yet produce (it writes exactly one transaction per
obligation) — this is a forward-looking fix for when multi-transaction test
data exists, not a change to today's output.

### 3. `SEQUENCE_NUMBER` — now populated (ISSUE 2)
Added `calc_sequence_number()`: the chosen transaction's 1-based rank among
that obligation's own transactions, oldest-first. Deliberately does **not**
read "max from the destination table" (unsafe with parallel Dataflow
workers — the write-up already flagged this). This is a pipeline-local
default, not a claim that it's the final numbering authority; ISSUE 2 stays
open in the write-up for business to confirm who owns numbering.
Verified: `1` on every row of the regression run (correct, since there's
only one transaction per obligation today).

### 4. `productCode` 15/16 exclusion (ISSUE 4) — still off, now a one-line switch
Re-checked the live `Lineage-OBL-v2` workbook end-to-end on 2026-10-09
(`BOL>OBL>Topic->AFS`, `OBL>Topic`, `Topic->AFS`, `OBL>Topic->AFS`,
`Business Rules -Cal fields`). Confirms the write-up: the rule is stated as
prose in the eligibility note, but **no tab sources `productCode` to any
topic/field.** Left off by default — `PRODUCT_CODE_FIELD = None` — rather
than invent one. Flip that one constant once business names the field.

### 5. `TOPIC_product_rates` (T33) — now read
The generator has always produced this file; the pipeline never read it
(the write-up calls this out under "Other code references"). It's now read
and passed into `BuildObligationRecords` as a side input. **Not joined to
any field** — the product-rates schema has no obligor/obligation column, so
there's nothing honest to join it on yet. This just removes the "silently
never read" gap; it changes zero output fields today.

### Not changed in this pass (left exactly as the write-up documents them as open)
- **ISSUE 1** (transaction history flattened to one row per obligation) —
  still open. Items 1-3 above reduce its symptoms (deterministic selection,
  a real SEQUENCE_NUMBER) but the real fix — one history row per
  transaction, with its own row key — needs the row-design decision the
  write-up already asks for. Not invented here.
- **ISSUE 5 / 6 / 7** (which process-type list is authoritative for
  `CURR_PRIN_BAL_AMT`; whether `INTEREST_PAID_YTD` should filter by year;
  `INT_PAYMENT_DATE`'s output format) — all business questions, unchanged.
- **ISSUE 8** (differing null defaults for `OBLIGOR_NUMBER`/`BANK` across
  legacy interfaces) — unchanged; still a business call on whether one
  combined row can serve every interface.
- The `CURR_PRIN_BAL_AMT` / `CURR_LINE_AMT` aggregation logic, the Loan/Line
  branch rules themselves, and the `BALANCE` formula's math were re-verified
  against the live sheet this pass and were already correct — not touched.

### Regression proof
```
python3 generate_dummy_data_all11_fixed.py --copies=3 --out_dir=dummy_data
python3 build_obligation_pipeline.py --input_dir=dummy_data --mode=dryrun --out_dir=merged_out
```
All values from section 8 of `obligation_pipeline_writeup.md` reproduced
exactly across 57 rows (3 copies, no double counting, all row keys unique).

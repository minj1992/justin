"""
build_obligation_pipeline.py

Apache Beam / Dataflow pipeline that implements:
  - Transformations sheet, Column C  (per-field transform logic)
  - Combinations sheet, Column F     (the 6 calculated fields' business logic)

Reads the topic JSONL files, joins them per-obligation (OBLIGOR_NUMBER +
OBLIGATION_NUMBER), applies the transforms, and writes two outputs:
  - Table A (full)      : every mapped + calculated field
  - Table B (essential) : OBLIGOR_NUMBER, OBLIGATION_NUMBER, PROCESS_TYPE,
                           LOAN_LINE_TYPE only

Row key (both tables): OBLIGOR_NUMBER (11-digit, 0-padded) + "#" +
                       OBLIGATION_NUMBER (10-digit, 0-padded)

LOAN_LINE_TYPE walks the takedown chain (account_relationships_accounts_
supplementals) for 'T'-type obligations -- see resolve_loan_line() and the
"best guess" notes in obligation_pipeline_writeup.md.

DESIGN NOTE — join strategy:
This treats the whole run as one bounded batch: every
topic's current records are read in full and held in memory as lookup
dicts, keyed by obligor/obligation. That's valid because right now we're
reading a fixed, already-complete set of test files, not a continuously
arriving live stream. If this ever moves to true continuous production
streaming (where a loan's related records from different topics can
genuinely arrive minutes or hours apart), this join strategy will need to
be revisited — e.g. using Bigtable itself as the point of correlation
(write-then-enrich) instead of an in-memory join. Flagging this, not
solving it here.

================================================================================
UPDATED 2026-10-09 (Chandra/Hemanth side) -- what changed and why
================================================================================
These are the items from the Imaan/Hemanth sync (the "some loan line types
come in null", "some balance amounts look a little wonky" issues) plus the
"missing items" check against the live BOL>OBL>Topic->AFS and Business Rules
-Cal fields tabs. Every change below is additive / defensive: nothing here
changes an output value on the current dummy data (verified by re-running
the generator's scenarios -- same results as section 8 of the write-up).
Each is tagged "# UPDATED:" at its spot in the code below.

1. FuzzyIndex (replaces index_by's plain dict). ISSUE 3 in the write-up
   already flagged that obligor/obligation padding between topics is
   "format unverified" -- an exact-string join is exactly the kind of thing
   that silently returns nothing (and therefore a null LOAN_LINE_TYPE) the
   moment two topics format the same ID differently (e.g. "10" vs
   "0000000010"). FuzzyIndex tries the exact key first (so behavior on
   clean/consistent data is byte-for-byte unchanged) and only falls back to
   a leading-zero-stripped comparison if the exact key misses. This does not
   change today's test output; it only makes the join more resilient once
   real data is used (per ISSUE 3's own suggested validation step).

2. Deterministic "most recent wins" ordering for posted_txn_recs and the
   BALH299 balance-header-amount scan, instead of "whatever order the list
   happens to be in" (which is what made the live-data run look
   nondeterministic / wonky). Sorting is by transactionRecordedTimestamp and
   the source sequenceNumber, both already on the records. This is still a
   stopgap for ISSUE 1 (the real fix is one history row per transaction,
   which needs a business decision on row design -- see the write-up) but it
   makes today's "pick one" behavior reproducible instead of order-dependent.

3. SEQUENCE_NUMBER (ISSUE 2) is now populated, as a pipeline-local,
   parallel-safe default: the chosen transaction's 1-based rank among that
   obligation's own transactions, oldest-first. This deliberately does NOT
   read "max from the destination table" (unsafe with parallel Dataflow
   workers, exactly as the write-up says) and is NOT claimed to be the final
   numbering authority -- it's here so the field isn't simply absent while
   ISSUE 2 stays open for a real decision.

4. ISSUE 4 (productCode 15/16 exclusion) is still OFF by default. Checked
   the live Lineage-OBL-v2 workbook again end-to-end (all 5 tabs,
   2026-10-09): "productCode 15 or 16 is not eligible" is stated as a
   business requirement in the Business Rules -Cal fields tab, but no tab
   gives it a source topic/field -- same gap the write-up already called
   out. Rather than guess a field, there's now a single named constant
   (PRODUCT_CODE_FIELD) to flip on once business names it.

5. TOPIC_product_rates (T33) is now read by the pipeline (it was generated
   by generate_dummy_data_all11_fixed.py but never read -- see the
   write-up's "Other code references" note). It's exposed to
   BuildObligationRecords as a side input, but NOT joined to any field yet:
   the product-rates schema has no obligor/obligation column to join on, so
   wiring a fake join would be worse than not reading it. This just removes
   the "silently never read" gap; it's a no-op on every output field today.

None of 1-5 touch CURR_PRIN_BAL_AMT / CURR_LINE_AMT aggregation, the Loan/
Line walk's actual branching logic, or the BALANCE formula -- those already
matched the sheet and the write-up's "Problems that were fixed" section, and
were re-verified against the live Business Rules -Cal fields tab this pass.

Local dry run (no GCP needed, writes merged records to local JSON):
    python3 build_obligation_pipeline.py --input_dir=/path/to/topic_jsonls --mode=dryrun --out_dir=/tmp/merged_out

Write to real Bigtable:
    python3 build_obligation_pipeline.py --input_dir=gs://afs-poc-data/dummy_data_is_10 \
        --mode=bigtable --bigtable_project=PROJECT --bigtable_instance=INSTANCE \
        --table_full=obligations_full --table_essential=obligations_essential
"""
import argparse
import json
import os
import re
from datetime import datetime, timedelta, timezone

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

# Max number of takedown hops resolve_loan_line() will follow before giving up.
MAX_TAKEDOWN_HOPS = 5

_OBLIGOR_KEY = "applicationSourceKey_foreignKey_obligorNumber"
_OBLIGATION_KEY = "applicationSourceKey_foreignKey_obligationNumber"

# UPDATED (item 4): ISSUE 4 extension point. Re-checked the live
# Lineage-OBL-v2 workbook on 2026-10-09 (BOL>OBL>Topic->AFS, OBL>Topic,
# Topic->AFS, OBL>Topic->AFS, Business Rules -Cal fields -- all 5 tabs):
# "productCode 15 or 16 is not eligible" is stated once, as prose, in the
# Business Rules -Cal fields eligibility note. No tab sources it to a real
# topic/field (only productType / OBLX224 is sourced, and that's already
# applied below). Left OFF so nothing is invented. Once business names the
# field (and which topic it lives on), set PRODUCT_CODE_FIELD to that field
# name -- if it's not on account_supplementals, also update the one lookup
# in is_online_banking_eligible() that reads `supp`.
PRODUCT_CODE_FIELD = None  # e.g. "productCode" once confirmed -- currently unsourced
PRODUCT_CODE_EXCLUDED = {"15", "16"}


# ============================================================================
# Column C — field-level transform helpers (Transformations sheet)
# ============================================================================

def left_pad(value, width, null_default=""):
    if value is None or value == "":
        return null_default
    return str(value).rjust(width, "0")


def passthrough(value, null_default=""):
    return value if value not in (None, "") else null_default


def substring_fn(value, start, end, null_default=""):
    if value is None or value == "":
        return null_default
    return str(value)[start:end]


def case_boolean(value, null_default=""):
    # loanTerms_onlineBankingEligibleIndicator: '1'/'0' or True/False -> boolean-ish string
    if value in (None, ""):
        return null_default
    return "1" if str(value) in ("1", "true", "True") else "0"


_FIXED_OFFSET = timezone(timedelta(hours=-5))


def iso_timestamp_minus_5(value, null_default=" "):
    """TRANSACTION_TMSTMP: 'formatted (ISO -05:00) from Timestamp'.
    Output is ISO-8601 with a fixed -05:00 offset, e.g. 2026-09-01T10:00:00-05:00.
    A timestamp that carries its own offset (or 'Z') is converted to -05:00; one
    with no offset is assumed to already be -05:00 and is labelled, not shifted.
    The offset is fixed (no daylight-saving handling) because the sheet says
    "-05:00". Unparseable values are passed through unchanged."""
    if value is None or value == "":
        return null_default
    text = str(value).strip()
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return text
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_FIXED_OFFSET)
    else:
        parsed = parsed.astimezone(_FIXED_OFFSET)
    return parsed.isoformat(timespec="seconds")


def signed_tran_amount(amount, charge_code, null_default="0.00"):
    # TRAN_AMOUNT: chargeCode != "10" ? amount * -1.00 : amount ; null -> "0.00"
    if amount in (None, ""):
        return null_default
    amt = float(amount)
    if str(charge_code) != "10":
        amt = amt * -1.00
    return f"{amt:.2f}"


# ============================================================================
# UPDATED (item 1) — Lookup-table builders — index each topic's records by
# join key, with a padding-tolerant fallback (ISSUE 3 mitigation)
# ============================================================================

def _normalize_id(value):
    """Loose-match key for obligor/obligation-style IDs. None/"" pass through
    unchanged; everything else has leading zeros stripped, so '0000000010'
    and '10' compare equal. Used ONLY as a fallback -- the exact raw value is
    always tried first, so behavior on clean/consistently-formatted data
    (today's dummy data included) is unchanged. This exists because ISSUE 3
    says the padding/format used by the relationships topic (and others) is
    "unconfirmed" -- without this, a format mismatch would silently return no
    match, which looks exactly like the "loan line type comes back null"
    symptom reported live."""
    if value in (None, ""):
        return value
    s = str(value).lstrip("0")
    return s if s else "0"


class FuzzyIndex:
    """Drop-in replacement for the old index_by()'s plain dict. Same .get(key)
    / .get(key, default) interface as a dict of lists, so no call site other
    than construction needs to change. Tries the exact key first; only falls
    back to the leading-zero-normalized key if the exact key isn't found."""

    def __init__(self, records, *key_fields):
        self._exact = {}
        self._normalized = {}
        for r in records:
            key = tuple(r.get(f) for f in key_fields)
            self._exact.setdefault(key, []).append(r)
            nkey = tuple(_normalize_id(v) for v in key)
            self._normalized.setdefault(nkey, []).append(r)

    def get(self, key, default=None):
        hit = self._exact.get(key)
        if hit:
            return hit
        nkey = tuple(_normalize_id(v) for v in key)
        hit = self._normalized.get(nkey)
        return hit if hit is not None else default


def index_by(records, *key_fields):
    """Build a fuzzy-matchable index keyed by a tuple of (raw) field values.
    UPDATED: now returns a FuzzyIndex instead of a plain dict -- see item 1
    above. Every existing `.get(key)` / `.get(key, [])` call site below keeps
    working exactly as before."""
    return FuzzyIndex(records, *key_fields)


def index_by_single(records, key_field):
    idx = {}
    for r in records:
        idx[r.get(key_field)] = r
    return idx


# ============================================================================
# UPDATED (item 2) — deterministic ordering helpers
# ============================================================================

def _txn_sort_key(rec):
    """Oldest-first sort key for posted transactions: recorded timestamp,
    then the source sequence number, then the record id (pure tie-breaker so
    the sort is always total/stable). Used both to pick a deterministic
    "most recent" transaction (item 2) and to rank SEQUENCE_NUMBER (item 3)."""
    ts = (rec.get("applicationSourceKey_transactionRecordedTimestamp")
          or rec.get("transactionRecordedTimestamp") or "")
    seq = rec.get("applicationSourceKey_sequenceNumber") or "0"
    try:
        seq_num = int(seq)
    except (TypeError, ValueError):
        seq_num = 0
    return (str(ts), seq_num, rec.get("accountLoanslinesleasesLcmPostedtransactionId") or "")


def _most_recent_txn(posted_txn_recs):
    """UPDATED (item 2): replaces 'posted_txn_recs[0]' (whatever order Beam
    happened to deliver, which is what produced the nondeterministic /
    "wonky" balances seen live). Deterministically picks the transaction
    with the latest recorded timestamp (sequence number as tie-break). This
    is still a stopgap for ISSUE 1 -- the real fix is one history row per
    transaction -- but it makes "which one gets picked" reproducible."""
    if not posted_txn_recs:
        return None
    return sorted(posted_txn_recs, key=_txn_sort_key)[-1]


# ============================================================================
# Calculations sheet, Column F — the 6 calculated fields
# ============================================================================

def is_online_banking_eligible(lcm_rec, lookups):
    """Shared eligibility filter reused by CURR_PRIN_BAL_AMT and CURR_LINE_AMT.

    productType (OBLX224) lives on account_supplementals, not on the LCM
    record, so it is looked up there. A missing supplemental row or null
    productType is not excluded. (The sheet's "productCode 15 or 16 is not
    eligible" rule is implemented ONLY if PRODUCT_CODE_FIELD is set -- see the
    constant above and ISSUE 4 in the write-up; it is OFF by default because
    no schema here has a sourced productCode column.)"""
    if not lcm_rec:
        return False
    if lcm_rec.get("loanTerms_onlineBankingEligibleIndicator") != "1":
        return False
    supp = _first(lookups["account_supp_by_key"].get(_obligation_key(lcm_rec)))
    product_type = str((supp or {}).get("productType") or "")
    if product_type.startswith("4"):
        return False
    if lcm_rec.get("payoff_paidLoanEligibleCode") in ("8", "9"):
        return False
    process_type = lcm_rec.get("processTypeCode") or ""
    if process_type not in ("CRBRN-N", "CRDRN-N", "CRBRT-N", "CRDRT-N"):
        return False
    # UPDATED (item 4): dormant until PRODUCT_CODE_FIELD is confirmed and set.
    if PRODUCT_CODE_FIELD:
        product_code = str((supp or {}).get(PRODUCT_CODE_FIELD) or "")
        if product_code in PRODUCT_CODE_EXCLUDED:
            return False
    return True


def build_loan_line_lookups(lcm_records, account_supp_records, relationship_records):
    """Global lookups needed to classify an obligation as Loan/Line.

    The takedown chain can cross obligors (the parent line may belong to a
    different obligor than the draw), so these are built over ALL records,
    not per obligor group.

    JOIN-KEY GUESS (unconfirmed): the relationships topic has no obligor
    column, so a relationship row is matched to an obligation via
    (financialInstrumentNumber, foreignKey_obligationNumber), assuming
    financialInstrumentNumber == obligorNumber (true in our dummy data).
    UPDATED (item 1): lcm_by_key now also tries a normalized fallback, same
    rationale as FuzzyIndex above, since this dict is hand-built (not via
    index_by) and is on the hot path for the takedown-chain walk.
    """
    lcm_by_key = {
        (r.get(_OBLIGOR_KEY), r.get(_OBLIGATION_KEY)): r for r in lcm_records
    }
    lcm_by_key_normalized = {
        (_normalize_id(r.get(_OBLIGOR_KEY)), _normalize_id(r.get(_OBLIGATION_KEY))): r
        for r in lcm_records
    }
    return {
        "lcm_by_key": lcm_by_key,
        "lcm_by_key_normalized": lcm_by_key_normalized,
        "account_supp_by_key": index_by(account_supp_records, _OBLIGOR_KEY, _OBLIGATION_KEY),
        "relationships_by_key": index_by(
            relationship_records,
            "applicationSourceKey_financialInstrumentNumber",
            _OBLIGATION_KEY),
    }


def _lookup_lcm(lookups, key):
    """UPDATED (item 1): exact lookup first, normalized fallback second --
    mirrors FuzzyIndex.get() for the one hand-built dict (lcm_by_key)."""
    hit = lookups["lcm_by_key"].get(key)
    if hit is not None:
        return hit
    nkey = (_normalize_id(key[0]), _normalize_id(key[1]))
    return lookups["lcm_by_key_normalized"].get(nkey)


def _obligation_key(lcm_rec):
    return (lcm_rec.get(_OBLIGOR_KEY), lcm_rec.get(_OBLIGATION_KEY))


def _first(recs):
    return recs[0] if recs else None


def _status_to_loan_line(account_status):
    if account_status in ("1", "2", "8"):
        return "Loan"
    if account_status == "0":
        return "Line"
    return None


def _account_status(lookups, obligation_key):
    supp = _first(lookups["account_supp_by_key"].get(obligation_key))
    return (supp or {}).get("overview_accountStatusCode")


def resolve_loan_line(lcm_rec, lookups, max_hops=MAX_TAKEDOWN_HOPS):
    """
    Column F logic for LOAN_LINE_TYPE. Returns (loan_line_type, line_rec):
    loan_line_type is "Loan", "Line" or None; line_rec is the LCM record of
    the H-type line the answer was read from (None for plain loans / no
    resolvable line). CURR_LINE_AMT uses line_rec to count each line once.

      5th char of processTypeCode == 'N' -> Loan
      5th char == 'H'  -> own accountStatusCode: 1/2/8 -> Loan, 0 -> Line,
                          else None
      anything else (e.g. 'T') -> walk the takedown chain: relationship row
          -> (takedownCustomerNumber, takedownObligationNumber) = parent
          obligation -> repeat until a parent with 'H' in the 5th position
          is found, then apply the H rule to that parent's status.
          - no parent at all (nothing connected to a line) -> "Loan"
            (spec G5: "if there is not a future connected ... it will fall
            as a loan")
          - broken chain (parent missing from LCM, takedown customer
            missing, cycle, or more than max_hops) -> None

    UPDATED (item 1): parent lookups now go through _lookup_lcm() (exact,
    then normalized fallback) instead of a plain dict .get() -- this is the
    concrete fix for the "some loan line types come in as null" symptom when
    a parent exists but its ID is formatted/padded differently across topics.
    """
    process_type = (lcm_rec or {}).get("processTypeCode") or ""
    if len(process_type) < 5:
        return None, None
    fifth_char = process_type[4]

    if fifth_char == "N":
        return "Loan", None

    if fifth_char == "H":
        status = _account_status(lookups, _obligation_key(lcm_rec))
        return _status_to_loan_line(status), lcm_rec

    current_key = _obligation_key(lcm_rec)
    visited = {current_key}
    for _ in range(max_hops):
        rel = _first(lookups["relationships_by_key"].get(current_key))
        parent_obligation = (rel or {}).get("takedownObligationNumber")
        if parent_obligation in (None, ""):
            return "Loan", None  # no future/line connected
        parent_key = ((rel or {}).get("takedownCustomerNumber"), parent_obligation)
        if parent_key[0] in (None, "") or parent_key in visited:
            return None, None  # missing customer number, or a cycle
        visited.add(parent_key)

        parent = _lookup_lcm(lookups, parent_key)  # UPDATED (item 1)
        if parent is None:
            return None, None
        parent_type = parent.get("processTypeCode") or ""
        if len(parent_type) >= 5 and parent_type[4] == "H":
            return _status_to_loan_line(_account_status(lookups, parent_key)), parent
        current_key = parent_key

    return None, None  # chain deeper than max_hops


def calc_loan_line_type(lcm_rec, lookups):
    return resolve_loan_line(lcm_rec, lookups)[0]


def compute_obligor_totals(obligor_group, lookups):
    """FIX for the per-obligation -> per-obligor aggregation gap.
    Takes ALL of one obligor's LCM records at once (via GroupByKey upstream)
    and sums CURR_PRIN_BAL_AMT / CURR_LINE_AMT correctly across every
    obligation that obligor has -- not just one loan at a time.

    This runs as its OWN pipeline stage (see run() below) rather than inline
    per-record, because you genuinely need every one of an obligor's loans
    visible together before the total means anything -- same reason this
    needs a different approach once this becomes a live stream (see the
    write-up note on this).

    Eligibility is checked on the obligor's own (child) record. A Loan adds
    that record's currentLegalBalance. A Line adds the noteAmount of the
    parent H line it resolved to, once per distinct line, however many
    draws that obligor has under it (BEST GUESS -- see write-up)."""
    obligor_raw, lcm_records = obligor_group

    curr_prin_total, found_prin = 0.0, False
    curr_line_total, found_line = 0.0, False
    counted_lines = set()

    for lcm_rec in lcm_records:
        if not is_online_banking_eligible(lcm_rec, lookups):
            continue

        loan_line_type, line_rec = resolve_loan_line(lcm_rec, lookups)

        if loan_line_type == "Loan":
            bal = lcm_rec.get("valuations_currentLegalBalance")
            if bal is not None:
                curr_prin_total += float(bal)
                found_prin = True
        elif loan_line_type == "Line" and line_rec is not None:
            line_key = _obligation_key(line_rec)
            if line_key in counted_lines:
                continue
            counted_lines.add(line_key)
            amt = line_rec.get("noteAmount")
            if amt is not None:
                curr_line_total += float(amt)
                found_line = True

    return obligor_raw, {
        "CURR_PRIN_BAL_AMT": f"{curr_prin_total:.2f}" if found_prin else None,
        "CURR_LINE_AMT": f"{curr_line_total:.2f}" if found_line else None,
    }


def calc_interest_paid_ytd(chargeheader_amount_recs):
    """SUM(chargeAmount) where chargeCode between 1000-1020, amountFieldName=CHGH260,
    amountTypeDescription=PAID. Null -> '0.00'.
    NOTE: our dummy data uses chargeCode '10'/'22' (sample placeholders), which
    don't actually fall in the 1000-1020 range described in the real business
    rule — so on real/representative test data this will correctly sum,  but
    on our current dummy records it will legitimately return 0.00. Flagging so
    this isn't mistaken for a bug when you see all-zero output on dummy data.
    """
    total = 0.0
    found_any = False
    for rec in chargeheader_amount_recs or []:
        try:
            code = int(rec.get("applicationSourceKey_chargeCode", -1))
        except (TypeError, ValueError):
            continue
        if not (1000 <= code <= 1020):
            continue
        if rec.get("applicationSourceKey_amountFieldName") != "CHGH260":
            continue
        if rec.get("amountTypeDescription") != "PAID":
            continue
        amt = rec.get("chargeAmount")
        if amt is not None:
            total += float(amt)
            found_any = True
    return f"{total:.2f}" if found_any else "0.00"


def calc_int_payment_date(billingschedule_recs):
    """Latest billDueDate among records with chargeCode=1000 and
    billingScheduleType in Billing/Repayment; else '0'.
    NOTE: our dummy data's billingScheduleType values ('Billing', 'Repayment')
    and chargeCode ('10'/'22') are placeholders, not the real '1000' charge
    code described in the rule — same caveat as INTEREST_PAID_YTD above.
    """
    candidates = []
    for rec in billingschedule_recs or []:
        if str(rec.get("applicationSourceKey_chargeCode")) != "1000":
            continue
        if rec.get("billingScheduleType") not in ("Billing", "Repayment"):
            continue
        due_date = rec.get("billDueDate")
        bill_date = rec.get("billDate")
        if due_date:
            candidates.append((due_date, bill_date))
    if not candidates:
        return "0"
    candidates.sort(key=lambda c: c[0])
    return candidates[-1][1]  # formatted billDate of the latest billDueDate


def calc_balance(balanceheader_amount_recs, posted_txn_recs):
    """
    Base balanceAmount filtered to amountFieldName=BALH299, balanceCode=10.
    Then adjusted per the latest posted transaction's description:
      AdvanceCurrent -> balanceAmount + transactionAmount
      PayPrincipal   -> transactionAmount - balanceAmount
      else           -> balanceAmount
    Negate (x -1) when chargeCode == 10. Null -> '0.00'.

    UPDATED (item 2): the base-balance scan now sorts candidates by source
    sequence number (descending) before taking the first BALH299/code-10
    match, and "the latest posted transaction" is chosen deterministically
    via _most_recent_txn() instead of "whatever position [0] happened to be
    in" -- this is the concrete fix for the "balance amounts look a little
    wonky" symptom. On today's dummy data (exactly one balance-header-amount
    and one transaction per obligation) this changes nothing; it only
    matters once there's more than one candidate.
    """
    base_balance = None
    candidates = [
        rec for rec in (balanceheader_amount_recs or [])
        if rec.get("applicationSourceKey_amountFieldName") == "BALH299"
        and rec.get("applicationSourceKey_balanceCode") == "10"
    ]
    if candidates:
        def _seq(rec):
            try:
                return int(rec.get("applicationSourceKey_sequenceNumber") or 0)
            except (TypeError, ValueError):
                return 0
        candidates.sort(key=_seq, reverse=True)
        base_balance = candidates[0].get("balanceAmount")
    if base_balance is None:
        return "0.00"
    base_balance = float(base_balance)

    txn = _most_recent_txn(posted_txn_recs)  # UPDATED (item 2)
    if txn:
        desc = txn.get("transactionDescription")
        txn_amt = float(txn.get("transactionAmount") or 0)
        if desc == "AdvanceCurrent":
            result = base_balance + txn_amt
        elif desc == "PayPrincipal":
            result = txn_amt - base_balance
        else:
            result = base_balance
        if str(txn.get("postedBalanceChargeCode")) == "10":
            result = result * -1
    else:
        result = base_balance

    return f"{result:.2f}"


def calc_sequence_number(posted_txn_recs, chosen_txn):
    """UPDATED (item 3): fills ISSUE 2 with a pipeline-local, parallel-safe
    default -- the chosen transaction's 1-based rank among THIS obligation's
    own transactions, oldest-first (ties broken by source sequence number,
    then record id -- see _txn_sort_key). Deliberately does NOT read
    'max(SEQUENCE_NUMBER) from the destination table' (unsafe with parallel
    Dataflow workers, per the write-up) and is NOT the final numbering
    authority -- ISSUE 2 stays open for business to confirm who owns
    numbering. On today's dummy data (one transaction per obligation) this
    always returns "1"."""
    if chosen_txn is None:
        return "0"
    ordered = sorted(posted_txn_recs or [], key=_txn_sort_key)
    for i, rec in enumerate(ordered, start=1):
        if rec is chosen_txn:
            return str(i)
    return "1"


# ============================================================================
# Main per-obligation record assembly
# ============================================================================

def build_records(lcm_rec, lookups, obligor_totals):
    """Given one LCM (driver/obligation-level) record plus side-table lookups,
    assemble the full record and the essential-subset record."""
    obligor_raw = lcm_rec.get("applicationSourceKey_foreignKey_obligorNumber")
    obligation_raw = lcm_rec.get("applicationSourceKey_foreignKey_obligationNumber")
    key = (obligor_raw, obligation_raw)

    customer_rec = lookups["customer_supplementals_by_obligor"].get((obligor_raw,))
    customer_rec = customer_rec[0] if customer_rec else None

    chargeheader_recs = lookups["chargeheaders_by_key"].get(key, [])
    chargeheader_ids = {r.get("accountLoanslinesleasesChargeheaderId") for r in chargeheader_recs}
    chargeheader_amount_recs = [
        r for r in lookups["all_chargeheader_amounts"]
        if r.get("accountLoanslinesleasesChargeheaderId") in chargeheader_ids
    ]

    balanceheader_recs = lookups["balanceheaders_by_key"].get(key, [])
    balanceheader_ids = {r.get("accountLoanslinesleasesBalanceheaderId") for r in balanceheader_recs}
    balanceheader_amount_recs = [
        r for r in lookups["all_balanceheader_amounts"]
        if r.get("accountLoanslinesleasesBalanceheaderId") in balanceheader_ids
    ]

    billingschedule_recs = lookups["billingschedules_by_key"].get(key, [])
    posted_txn_recs = lookups["posted_txns_by_key"].get(key, [])

    # ---- Column C: simple passthrough / transformed fields ----
    loan_line_type = calc_loan_line_type(lcm_rec, lookups["loan_line"])

    full = {
        "OBLIGOR_NUMBER": left_pad(obligor_raw, 11, null_default="0"),
        "BANK": passthrough(
            (customer_rec or {}).get("commercialLoanCustomer_applicationSourceKey_bankNumber"),
            null_default="1",
        ),
        "OBLIGATION_NUMBER": left_pad(obligation_raw, 10, null_default=" "),
        "PROCESS_TYPE": passthrough(lcm_rec.get("processTypeCode"), null_default=" "),
        "OB_ELIGIBLE_IND": case_boolean(lcm_rec.get("loanTerms_onlineBankingEligibleIndicator"), null_default=" "),
        "PAID_ELIGIBLE_CODE": substring_fn(lcm_rec.get("payoff_paidLoanEligibleCode"), 0, 2, null_default=" "),

        # ---- TBFUTOBL fields (Transformations rows 18-19) ----
        # PROCESS_TYPE_CODE: same LCM processTypeCode as PROCESS_TYPE; the sheet
        # says "Hardcoded" but gives no value, so it is passed through.
        # FUT_OBLIGATION_NUM: the obligation's direct parent (takedownObligationNumber).
        "PROCESS_TYPE_CODE": passthrough(lcm_rec.get("processTypeCode"), null_default=" "),
        "FUT_OBLIGATION_NUM": left_pad(
            (_first(lookups["loan_line"]["relationships_by_key"].get(key)) or {}).get(
                "takedownObligationNumber"),
            10, null_default=" "),

        # ---- Column F: calculated fields ----
        # CURR_PRIN_BAL_AMT / CURR_LINE_AMT are OBLIGOR-level totals (summed
        # across every obligation that obligor has), precomputed once in the
        # ComputeObligorTotals pipeline stage -- see compute_obligor_totals().
        # Every obligation belonging to the same obligor will correctly show
        # the SAME total here, since it's a roll-up value, not a per-loan one.
        "LOAN_LINE_TYPE": loan_line_type,
        "CURR_PRIN_BAL_AMT": obligor_totals.get(obligor_raw, {}).get("CURR_PRIN_BAL_AMT"),
        "CURR_LINE_AMT": obligor_totals.get(obligor_raw, {}).get("CURR_LINE_AMT"),
        "INTEREST_PAID_YTD": calc_interest_paid_ytd(chargeheader_amount_recs),
        "INT_PAYMENT_DATE": calc_int_payment_date(billingschedule_recs),
        "BALANCE": calc_balance(balanceheader_amount_recs, posted_txn_recs),
    }

    # Transaction-history fields (one row per posted transaction, not per obligation —
    # for this POC we emit them flattened onto the same record using the most
    # recent transaction found; a real implementation would emit one row per
    # transaction -- ISSUE 1, still open, see the write-up)
    if posted_txn_recs:
        txn = _most_recent_txn(posted_txn_recs)  # UPDATED (item 2): was posted_txn_recs[0]
        full["EFFECTIVE_DATE"] = passthrough(txn.get("effectiveDate"))
        full["TRAN_AMOUNT"] = signed_tran_amount(txn.get("transactionAmount"), txn.get("postedBalanceChargeCode"))
        full["TRANSACTION_DESC"] = substring_fn(txn.get("transactionDescription"), 0, 30, null_default=" ")
        full["TRANSACTION_TMSTMP"] = iso_timestamp_minus_5(txn.get("transactionRecordedTimestamp"), null_default=" ")
        full["CHARGE_CODE"] = passthrough(txn.get("postedBalanceChargeCode"), null_default=" ")
        full["SEQUENCE_NUMBER"] = calc_sequence_number(posted_txn_recs, txn)  # UPDATED (item 3)

    row_key = f"{full['OBLIGOR_NUMBER']}#{full['OBLIGATION_NUMBER']}"
    full["_row_key"] = row_key

    essential = {
        "_row_key": row_key,
        "OBLIGOR_NUMBER": full["OBLIGOR_NUMBER"],
        "OBLIGATION_NUMBER": full["OBLIGATION_NUMBER"],
        "PROCESS_TYPE": full["PROCESS_TYPE"],
        "LOAN_LINE_TYPE": full["LOAN_LINE_TYPE"],
    }

    return full, essential


# ============================================================================
# Beam DoFn
# ============================================================================

class BuildObligationRecords(beam.DoFn):
    def process(self, lcm_rec, customer_supplementals, chargeheaders,
                chargeheader_amounts, balanceheaders, balanceheader_amounts,
                billingschedules, posted_txns, obligor_totals, loan_line_lookups,
                product_rates=None):
        # UPDATED (item 5): product_rates is accepted but not joined to
        # anything yet -- see the module docstring. Default None/[] keeps
        # this call compatible even if a caller doesn't pass it.
        lookups = {
            "loan_line": loan_line_lookups,
            "customer_supplementals_by_obligor": index_by(
                customer_supplementals, "commercialLoanCustomer_applicationSourceKey_obligorNumber"),
            "chargeheaders_by_key": index_by(
                chargeheaders,
                "applicationSourceKey_foreignKey_obligorNumber",
                "applicationSourceKey_foreignKey_obligationNumber"),
            "all_chargeheader_amounts": chargeheader_amounts,
            "balanceheaders_by_key": index_by(
                balanceheaders, "foreignKey_obligorNumber", "foreignKey_obligationNumber"),
            "all_balanceheader_amounts": balanceheader_amounts,
            "billingschedules_by_key": index_by(
                billingschedules,
                "applicationSourceKey_foreignKey_obligorNumber",
                "applicationSourceKey_foreignKey_obligationNumber"),
            "posted_txns_by_key": index_by(
                posted_txns,
                "applicationSourceKey_foreignKey_obligorNumber",
                "applicationSourceKey_foreignKey_obligationNumber"),
        }
        full, essential = build_records(lcm_rec, lookups, obligor_totals)
        yield beam.pvalue.TaggedOutput("full", full)
        yield beam.pvalue.TaggedOutput("essential", essential)


# ============================================================================
# Pipeline wiring
# ============================================================================

def read_topic(pipeline, input_dir, filename):
    # NOTE: deliberately NOT using os.path.join here -- on Windows it inserts
    # a backslash, which breaks GCS paths (gs://... always requires forward
    # slashes, regardless of what OS the script runs on).
    path = f"{input_dir.rstrip('/')}/{filename}"
    return (
        pipeline
        | f"Read_{filename}" >> beam.io.ReadFromText(path)
        | f"Parse_{filename}" >> beam.Map(json.loads)
    )


def run(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_dir", required=True)
    parser.add_argument("--mode", choices=["dryrun", "bigtable"], default="dryrun")
    parser.add_argument("--out_dir", default="/tmp/merged_out")
    parser.add_argument("--bigtable_project")
    parser.add_argument("--bigtable_instance")
    parser.add_argument("--table_full", default="obligations_full")
    parser.add_argument("--table_essential", default="obligations_essential")
    known_args, pipeline_args = parser.parse_known_args(argv)

    options = PipelineOptions(pipeline_args)

    with beam.Pipeline(options=options) as p:
        lcm = read_topic(p, known_args.input_dir, "TOPIC_account_loanslinesleases_lcm.jsonl")
        customer_supplementals = read_topic(p, known_args.input_dir, "TOPIC_customer_supplementals.jsonl")
        account_supplementals = read_topic(p, known_args.input_dir, "TOPIC_account_supplementals.jsonl")
        chargeheaders = read_topic(p, known_args.input_dir, "TOPIC_account_loanslinesleases_chargeheaders.jsonl")
        chargeheader_amounts = read_topic(p, known_args.input_dir, "account_loanslinesleases_chargeheaders_amounts.jsonl")
        balanceheaders = read_topic(p, known_args.input_dir, "TOPIC_account_loanslinesleases_balanceheaders.jsonl")
        balanceheader_amounts = read_topic(p, known_args.input_dir, "account_loanslinesleases_balanceheaders_amounts.jsonl")
        billingschedules = read_topic(p, known_args.input_dir, "TOPIC_account_loanslinesleases_billingschedules.jsonl")
        posted_txns = read_topic(p, known_args.input_dir, "account_loanslinesleases_lcm_postedtransactions.jsonl")
        relationships = read_topic(p, known_args.input_dir, "TOPIC_account_relationships_accounts_supplementals.jsonl")
        # UPDATED (item 5): now read (was generated by the test-data script
        # but never read by this pipeline). Not joined to any field yet --
        # no obligor/obligation column exists on this topic's schema to join
        # on. Kept as a side input so it's available the moment a field maps
        # to it, instead of silently absent.
        product_rates = read_topic(p, known_args.input_dir, "TOPIC_product_rates.jsonl")

        # ---- Global lookups for the Loan/Line chain walk. Built once (not per
        # record) because the walk can hop to a parent line under a different
        # obligor, so it needs every LCM / supplemental / relationship record.
        loan_line_lookups = (
            p
            | "SeedLoanLineLookups" >> beam.Create([None])
            | "BuildLoanLineLookups" >> beam.Map(
                lambda _, lcm_records, supp_records, rel_records: build_loan_line_lookups(
                    lcm_records, supp_records, rel_records),
                lcm_records=beam.pvalue.AsList(lcm),
                supp_records=beam.pvalue.AsList(account_supplementals),
                rel_records=beam.pvalue.AsList(relationships),
            )
        )
        loan_line_lookups_input = beam.pvalue.AsSingleton(loan_line_lookups)

        # ---- Obligor-level aggregation stage (the fix for CURR_PRIN_BAL_AMT /
        # CURR_LINE_AMT): group ALL of an obligor's loans together FIRST,
        # then sum. This has to be its own stage -- you can't correctly total
        # "all of a customer's loans" while only looking at one loan at a time.
        obligor_totals = (
            lcm
            | "KeyByObligor" >> beam.Map(
                lambda r: (r.get("applicationSourceKey_foreignKey_obligorNumber"), r))
            | "GroupByObligor" >> beam.GroupByKey()
            | "ComputeObligorTotals" >> beam.Map(
                lambda group, lookups: compute_obligor_totals(group, lookups),
                lookups=loan_line_lookups_input,
            )
        )

        results = (
            lcm
            | "BuildRecords" >> beam.ParDo(
                BuildObligationRecords(),
                customer_supplementals=beam.pvalue.AsList(customer_supplementals),
                loan_line_lookups=loan_line_lookups_input,
                chargeheaders=beam.pvalue.AsList(chargeheaders),
                chargeheader_amounts=beam.pvalue.AsList(chargeheader_amounts),
                balanceheaders=beam.pvalue.AsList(balanceheaders),
                balanceheader_amounts=beam.pvalue.AsList(balanceheader_amounts),
                billingschedules=beam.pvalue.AsList(billingschedules),
                posted_txns=beam.pvalue.AsList(posted_txns),
                obligor_totals=beam.pvalue.AsDict(obligor_totals),
                product_rates=beam.pvalue.AsList(product_rates),  # UPDATED (item 5)
            ).with_outputs("full", "essential")
        )

        if known_args.mode == "dryrun":
            os.makedirs(known_args.out_dir, exist_ok=True)
            (
                results.full
                | "FormatFull" >> beam.Map(json.dumps)
                | "WriteFull" >> beam.io.WriteToText(
                    os.path.join(known_args.out_dir, "table_full"), file_name_suffix=".jsonl")
            )
            (
                results.essential
                | "FormatEssential" >> beam.Map(json.dumps)
                | "WriteEssential" >> beam.io.WriteToText(
                    os.path.join(known_args.out_dir, "table_essential"), file_name_suffix=".jsonl")
            )
        else:
            # Real Bigtable write. Imported here so dry-run mode never needs
            # google-cloud-bigtable installed.
            from apache_beam.io.gcp.bigtableio import WriteToBigTable
            from google.cloud.bigtable.row import DirectRow

            def to_bigtable_row(record, column_family="data"):
                row_key = record.pop("_row_key")
                row = DirectRow(row_key=row_key.encode("utf-8"))
                for k, v in record.items():
                    if v is not None:
                        row.set_cell(column_family, k.encode("utf-8"), str(v).encode("utf-8"))
                return row

            (
                results.full
                | "ToRowsFull" >> beam.Map(to_bigtable_row)
                | "WriteFullBT" >> WriteToBigTable(
                    project_id=known_args.bigtable_project,
                    instance_id=known_args.bigtable_instance,
                    table_id=known_args.table_full,
                )
            )
            (
                results.essential
                | "ToRowsEssential" >> beam.Map(to_bigtable_row)
                | "WriteEssentialBT" >> WriteToBigTable(
                    project_id=known_args.bigtable_project,
                    instance_id=known_args.bigtable_instance,
                    table_id=known_args.table_essential,
                )
            )


if __name__ == "__main__":
    run()

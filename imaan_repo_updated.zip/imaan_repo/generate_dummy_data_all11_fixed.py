"""
generate_dummy_data_all11_fixed.py

Scenario-based dummy data for all source topics. Field names match the actual
TOPIC_* SQL schemas (the .sql CREATE TABLE scripts from the "optimus"
database). Where a schema has BOTH a prefixed and an unprefixed version of the
same concept (e.g. 'effectiveDate' AND 'applicationSourceKey_effectiveDate'),
both are populated so nothing downstream silently gets a null.

'topic_name' is deliberately NOT in any record: each topic is already read /
published separately (one JSONL file per topic), so the pipeline knows which
topic a message belongs to without a field in the payload.

HOW THE DATA IS BUILT
Instead of cycling two fixed template records, the generator builds a set of
named SCENARIOS (see add_scenarios), each designed to exercise one branch of
the business rules in the Transformation_and_Calculation_guide.xlsx. Every
copy of the scenario set gets its own unique obligor and obligation numbers,
so scaling up never creates duplicate loans (the old generator repeated
obligor/obligation numbers, which double-counted CURR_PRIN_BAL_AMT).

Takedown chains are acyclic by construction: a draw only ever points at a
line/draw created before it in the same scenario.

Scenarios per copy (obligor offset -> what it tests):
  0  two plain N loans, one obligor      -> per-obligor sum; also carries the
                                            trigger data for BALANCE,
                                            INTEREST_PAID_YTD, INT_PAYMENT_DATE
  1  open line (status 0) + 2 T draws    -> Line; line amount counted once
  2  closed line (status 1) + 1 T draw   -> Loan via parent
  3  line with null status + 1 T draw    -> null
  4  orphan T draw (no relationship row) -> Loan (no line connected)
  5  multi-hop: T2 -> T1 -> H line       -> Line via two hops
  6  line + 2 INELIGIBLE T draws         -> Line label, but excluded from sums
  7  T draw whose parent line belongs to -> cross-obligor lookup
     scenario 1's obligor
  8  loan with productType 410 (excluded) + -> productType filter (reads
     loan with productType 500 (included)      account_supplementals)

Local test:  python generate_dummy_data_all11_fixed.py --copies=1
Upload:      python generate_dummy_data_all11_fixed.py --gcs_bucket=afs-poc-data \
                 --gcs_prefix=dummy_data_is_100 --records_per_topic=100
"""
import argparse
import json
import math
import os
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

TOPIC_NAMES = [
    "TOPIC_account_loanslinesleases_lcm",
    "TOPIC_product_rates",
    "TOPIC_customer_supplementals",
    "account_loanslinesleases_lcm_postedtransactions",
    "TOPIC_account_supplementals",
    "TOPIC_account_loanslinesleases_chargeheaders",
    "TOPIC_account_relationships_accounts_supplementals",
    "TOPIC_account_loanslinesleases_balanceheaders",
    "TOPIC_account_loanslinesleases_billingschedules",
    "account_loanslinesleases_chargeheaders_amounts",
    "account_loanslinesleases_balanceheaders_amounts",
]

LCM_RECORDS_PER_COPY = 19  # keep in sync with add_scenarios


@dataclass
class Obligation:
    obligor: str
    number: str
    process_type: str
    balance: float                      # valuations_currentLegalBalance
    note_amount: float                  # noteAmount
    status: Optional[str]               # account_supplementals overview_accountStatusCode
    takedown: Optional[Tuple[str, str]] = None   # (parent obligor, parent obligation)
    has_relationship_row: bool = True
    indicator: str = "1"                # loanTerms_onlineBankingEligibleIndicator
    paid_code: str = "0"                # payoff_paidLoanEligibleCode
    product_type: str = "100"           # account_supplementals productType
    base_balance: Optional[float] = None         # BALH299 / balanceCode 10 amount
    txn: Tuple[str, float, str] = ("AdvanceCurrent", 100.0, "10")
    # (code, amountTypeDescription, amountFieldName, amount)
    charges: List[Tuple[str, str, str, float]] = field(
        default_factory=lambda: [("1000", "PAID", "CHGH260", 100.0)])
    # (chargeCode, billingScheduleType, billDate, billDueDate)
    bills: List[Tuple[str, str, str, str]] = field(
        default_factory=lambda: [("1000", "Billing", "2026-09-01", "2026-10-01")])


def money(x):
    return f"{x:.2f}"


def add_obligation(topics, nid, ob):
    """Append one row to every per-obligation topic for this obligation."""
    app = "APP01"
    bank = "001"
    system = "AFSVISION"
    lcm_id = nid("T23")
    acct_id = nid("ACC")

    topics["TOPIC_account_loanslinesleases_lcm"].append({
        "accountLoanslinesleasesLcmId": lcm_id,
        "accountLoanslinesleaseId": acct_id,
        "applicationSourceKey_applicationSystem": system,
        "applicationSourceKey_financialInstrumentNumber": ob.obligor,
        "applicationSourceKey_foreignKey_applicationNumber": app,
        "applicationSourceKey_foreignKey_bankNumber": bank,
        "applicationSourceKey_foreignKey_obligationNumber": ob.number,
        "applicationSourceKey_foreignKey_obligorNumber": ob.obligor,
        "externalSourceTicklerReference": None,
        "processTypeCode": ob.process_type,
        "valuations_currentLegalBalance": money(ob.balance),
        "noteAmount": money(ob.note_amount),
        "loanTerms_onlineBankingEligibleIndicator": ob.indicator,
        "payoff_paidLoanEligibleCode": ob.paid_code,
    })

    topics["TOPIC_account_supplementals"].append({
        "accountSupplementalId": nid("T26"),
        "accountId": acct_id,
        "productType": ob.product_type,
        "productTypeDescription": "Commercial Loan",
        "applicationSourceKey_applicationSystem": system,
        "applicationSourceKey_financialInstrumentNumber": ob.obligor,
        "applicationSourceKey_foreignKey_obligorNumber": ob.obligor,
        "applicationSourceKey_foreignKey_obligationNumber": ob.number,
        "applicationSourceKey_foreignKey_bankNumber": bank,
        "applicationSourceKey_foreignKey_applicationNumber": app,
        "overview_accountStatusCode": ob.status,
    })

    if ob.has_relationship_row:
        parent_obligor, parent_obligation = ob.takedown or (None, None)
        topics["TOPIC_account_relationships_accounts_supplementals"].append({
            "accountRelationshipsAccountsSupplementalId": nid("T41"),
            "accountRelationshipsAccountId": acct_id,
            "applicationSourceKey_applicationSystem": system,
            # JOIN-KEY GUESS: this topic has no obligor column, so the
            # instrument number carries the obligor (see write-up).
            "applicationSourceKey_financialInstrumentNumber": ob.obligor,
            "applicationSourceKey_foreignKey_obligationNumber": ob.number,
            "takedownApplicationNumber": app if ob.takedown else None,
            "takedownCustomerNumber": parent_obligor,
            "takedownObligationNumber": parent_obligation,
        })

    for code, amount_type, field_name, amount in ob.charges:
        header_id = nid("T8")
        topics["TOPIC_account_loanslinesleases_chargeheaders"].append({
            "accountLoanslinesleasesChargeheaderId": header_id,
            "accountLoanslinesleaseId": acct_id,
            "applicationSourceKey_applicationSystem": system,
            "applicationSourceKey_foreignKey_applicationNumber": app,
            "applicationSourceKey_foreignKey_bankNumber": bank,
            "applicationSourceKey_chargeCode": code,
            "chargeCode": code,
            "applicationSourceKey_financialInstrumentNumber": ob.obligor,
            "applicationSourceKey_foreignKey_obligationNumber": ob.number,
            "applicationSourceKey_foreignKey_obligorNumber": ob.obligor,
        })
        topics["account_loanslinesleases_chargeheaders_amounts"].append({
            "accountLoanslinesleasesChargeheadersAmountId": nid("T12"),
            "accountLoanslinesleasesChargeheaderId": header_id,
            "applicationSourceKey_amountFieldName": field_name,
            "applicationSourceKey_applicationSystem": system,
            "applicationSourceKey_chargeCode": code,
            "applicationSourceKey_financialInstrumentNumber": ob.obligor,
            "applicationSourceKey_foreignKey_applicationNumber": app,
            "applicationSourceKey_foreignKey_bankNumber": bank,
            "applicationSourceKey_foreignKey_obligationNumber": ob.number,
            "applicationSourceKey_foreignKey_obligorNumber": ob.obligor,
            "amountTypeDescription": amount_type,
            "chargeAmount": money(amount),
        })

    for code, schedule_type, bill_date, due_date in ob.bills:
        topics["TOPIC_account_loanslinesleases_billingschedules"].append({
            "accountLoanslinesleasesBillingscheduleId": nid("T11"),
            "accountLoanslinesleaseId": acct_id,
            "applicationSourceKey_applicationSystem": system,
            "applicationSourceKey_foreignKey_applicationNumber": app,
            "applicationSourceKey_foreignKey_bankNumber": bank,
            "applicationSourceKey_chargeCode": code,
            "chargeCode": code,
            "applicationSourceKey_effectiveStartDate": bill_date,
            "effectiveStartDate": bill_date,
            "applicationSourceKey_financialInstrumentNumber": ob.obligor,
            "applicationSourceKey_foreignKey_obligationNumber": ob.number,
            "applicationSourceKey_foreignKey_obligorNumber": ob.obligor,
            "billDate": bill_date,
            "billDueDate": due_date,
            "billingScheduleType": schedule_type,
        })

    balance_header_id = nid("T7")
    topics["TOPIC_account_loanslinesleases_balanceheaders"].append({
        "accountLoanslinesleasesBalanceheaderId": balance_header_id,
        "accountLoanslinesleaseId": acct_id,
        "applicationSourceKey_applicationSystem": system,
        "applicationSourceKey_associatedPrincipalBalanceCode": "P",
        "associatedPrincipalBalanceCode": "P",
        "applicationSourceKey_balanceCode": "10",
        "balanceCode": "10",
        "foreignKey_bankNumber": bank,
        "applicationSourceKey_financialInstrumentNumber": ob.obligor,
        "foreignKey_obligationNumber": ob.number,
        "foreignKey_obligorNumber": ob.obligor,
        "applicationSourceKey_sequenceNumber": "1",
    })
    base_balance = ob.balance if ob.base_balance is None else ob.base_balance
    topics["account_loanslinesleases_balanceheaders_amounts"].append({
        "accountLoanslinesleasesBalanceheadersAmountId": nid("T15"),
        "accountLoanslinesleasesBalanceheaderId": balance_header_id,
        "applicationSourceKey_amountFieldName": "BALH299",
        "applicationSourceKey_applicationSystem": system,
        "applicationSourceKey_associatedPrincipalBalanceCode": "P",
        "applicationSourceKey_balanceCode": "10",
        "applicationSourceKey_foreignKey_applicationNumber": app,
        "applicationSourceKey_foreignKey_bankNumber": bank,
        "applicationSourceKey_foreignKey_obligationNumber": ob.number,
        "applicationSourceKey_foreignKey_obligorNumber": ob.obligor,
        "applicationSourceKey_financialInstrumentNumber": ob.obligor,
        "applicationSourceKey_sequenceNumber": "1",
        "balanceAmount": money(base_balance),
    })

    description, amount, charge_code = ob.txn
    topics["account_loanslinesleases_lcm_postedtransactions"].append({
        "accountLoanslinesleasesLcmId": lcm_id,
        "accountLoanslinesleasesLcmPostedtransactionId": nid("T13"),
        "applicationSourceKey_applicationSystem": system,
        "applicationSourceKey_effectiveDate": "2026-09-01",
        "effectiveDate": "2026-09-01",
        "applicationSourceKey_financialInstrumentNumber": ob.obligor,
        "applicationSourceKey_foreignKey_applicationNumber": app,
        "applicationSourceKey_foreignKey_bankNumber": bank,
        "applicationSourceKey_foreignKey_obligationNumber": ob.number,
        "applicationSourceKey_foreignKey_obligorNumber": ob.obligor,
        "applicationSourceKey_offsetSequenceNumber": "0",
        "applicationSourceKey_sequenceNumber": "1",
        "applicationSourceKey_transactionRecordedTimestamp": "2026-09-01T10:00:00",
        "transactionRecordedTimestamp": "2026-09-01T10:00:00",
        "transactionAmount": money(amount),
        "transactionDescription": description,
        "postedBalanceChargeCode": charge_code,
    })


def add_obligor_level_rows(topics, nid, obligor):
    topics["TOPIC_customer_supplementals"].append({
        "customerSupplementalId": nid("T19"),
        "customerId": nid("CUST"),
        "commercialLoanCustomer_applicationSourceKey_applicationSystem": "AFSVISION",
        "commercialLoanCustomer_applicationSourceKey_applicationNumber": "APP01",
        "commercialLoanCustomer_applicationSourceKey_bankNumber": "001",
        "commercialLoanCustomer_applicationSourceKey_obligorNumber": obligor,
    })


def add_scenarios(topics, nid, copy_index):
    """One full set of scenarios, with numbers unique to this copy."""
    def obligor(s):
        return str(10000 + copy_index * 10 + s)

    def number(s, k):
        return str((copy_index + 1) * 1000 + s * 20 + k)

    def add(ob):
        add_obligation(topics, nid, ob)

    for s in range(9):
        add_obligor_level_rows(topics, nid, obligor(s))

    # --- 0: two plain loans under one obligor (expect CURR_PRIN_BAL_AMT 22500.00)
    # Loan A carries the trigger data for the 3 formerly-untested calculated fields:
    #   INTEREST_PAID_YTD: 1000 PAID 120 + 1010 PAID 80 = 200.00
    #       (1030 is out of range, UNPAID is the wrong amount type, CHGH999 the wrong field)
    #   INT_PAYMENT_DATE: latest due date among code-1000 Billing/Repayment = 2026-11-01
    #       -> billDate 2026-10-01 (decoys: later due dates on code 1010 / type "Other")
    #   BALANCE: AdvanceCurrent -> (15000 + 500) * -1 (chargeCode 10) = -15500.00
    add(Obligation(
        obligor(0), number(0, 0), "CRBRN-N", 15000, 20000, "1",
        base_balance=15000, txn=("AdvanceCurrent", 500.0, "10"),
        charges=[
            ("1000", "PAID", "CHGH260", 120.0),
            ("1010", "PAID", "CHGH260", 80.0),
            ("1030", "PAID", "CHGH260", 999.0),
            ("1000", "UNPAID", "CHGH260", 555.0),
            ("1000", "PAID", "CHGH999", 444.0),
        ],
        bills=[
            ("1000", "Billing", "2026-09-01", "2026-10-01"),
            ("1000", "Repayment", "2026-10-01", "2026-11-01"),
            ("1010", "Billing", "2026-11-01", "2026-12-01"),
            ("1000", "Other", "2026-12-01", "2027-01-01"),
        ],
    ))
    # Loan B: PayPrincipal -> 750 - 8000 = -7250.00 (chargeCode 22, so NOT negated)
    add(Obligation(
        obligor(0), number(0, 1), "CRDRN-N", 7500, 10000, "1",
        base_balance=8000, txn=("PayPrincipal", 750.0, "22"),
    ))

    # --- 1: open line (status 0), two draws. Expect both draws = Line,
    #     CURR_LINE_AMT = 100000.00 (line counted once), CURR_PRIN_BAL_AMT null.
    line1 = (obligor(1), number(1, 0))
    add(Obligation(obligor(1), number(1, 0), "FRR-HA", 50000, 100000, "0"))
    add(Obligation(obligor(1), number(1, 1), "CRBRT-N", 20000, 20000, "1", takedown=line1))
    add(Obligation(obligor(1), number(1, 2), "CRBRT-N", 30000, 30000, "1", takedown=line1))

    # --- 2: closed line (status 1), one draw. Expect draw = Loan,
    #     CURR_PRIN_BAL_AMT = 10000.00, CURR_LINE_AMT null.
    line2 = (obligor(2), number(2, 0))
    add(Obligation(obligor(2), number(2, 0), "FRN-HG", 40000, 50000, "1"))
    add(Obligation(obligor(2), number(2, 1), "CRDRT-N", 10000, 10000, "1", takedown=line2))

    # --- 3: line with null status. Expect draw LOAN_LINE_TYPE null, totals null.
    line3 = (obligor(3), number(3, 0))
    add(Obligation(obligor(3), number(3, 0), "FRR-HA", 30000, 60000, None))
    add(Obligation(obligor(3), number(3, 1), "CRBRT-N", 5000, 5000, "1", takedown=line3))

    # --- 4: orphan draw, no relationship row. Expect Loan, CURR_PRIN_BAL_AMT 4000.00.
    add(Obligation(obligor(4), number(4, 0), "CRBRT-N", 4000, 4000, "1",
                   has_relationship_row=False))

    # --- 5: multi-hop. T2 -> T1 -> H line (status 0, note 80000).
    #     Expect both Line, CURR_LINE_AMT = 80000.00 once.
    line5 = (obligor(5), number(5, 0))
    t1 = (obligor(5), number(5, 1))
    add(Obligation(obligor(5), number(5, 0), "FRN-HA", 60000, 80000, "0"))
    add(Obligation(obligor(5), number(5, 1), "CRBRT-N", 1000, 1000, "1", takedown=line5))
    add(Obligation(obligor(5), number(5, 2), "CRDRT-N", 2000, 2000, "1", takedown=t1))

    # --- 6: open line + two ineligible draws. Both label as Line, but neither is
    #     summed (eligibility is checked on the draw): totals stay null.
    line6 = (obligor(6), number(6, 0))
    add(Obligation(obligor(6), number(6, 0), "FRR-HA", 70000, 90000, "0"))
    add(Obligation(obligor(6), number(6, 1), "CRBRT-N", 3000, 3000, "1",
                   takedown=line6, indicator="0"))
    add(Obligation(obligor(6), number(6, 2), "CRBRT-N", 3500, 3500, "1",
                   takedown=line6, paid_code="9"))

    # --- 7: draw under scenario 1's line (a different obligor).
    #     Expect Line, CURR_LINE_AMT = 100000.00 for THIS obligor too.
    add(Obligation(obligor(7), number(7, 0), "CRBRT-N", 2500, 2500, "1", takedown=line1))

    # --- 8: productType filter. The 410 loan (400-499) is excluded; the 500 loan counts.
    #     Expect CURR_PRIN_BAL_AMT = 2000.00 on both rows.
    add(Obligation(obligor(8), number(8, 0), "CRBRN-N", 6000, 6000, "1", product_type="410"))
    add(Obligation(obligor(8), number(8, 1), "CRBRN-N", 2000, 2000, "1", product_type="500"))


def build_topics(copies):
    topics = {name: [] for name in TOPIC_NAMES}
    ids = Counter()

    def nid(prefix):
        ids[prefix] += 1
        return f"{prefix}-{ids[prefix]:06d}"

    for c in range(copies):
        add_scenarios(topics, nid, c)
        topics["TOPIC_product_rates"].append({
            "productRateId": nid("T33"),
            "productId": "PROD-01",
            "applicationSourceKey_applicationSystem": "AFSVISION",
            "applicationSourceKey_bankNumber": "001",
            "applicationSourceKey_effectiveDate": "2026-09-01",
            "applicationSourceKey_effectiveTime": "10:00:00",
            "applicationSourceKey_externalSourceCustomerNameReference": "CUSTNAME01",
            "applicationSourceKey_rateNumber": "4.25",
            "applicationSourceKey_sequenceNumber": "1",
        })
    return topics


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out_dir", default="dummy_data_all11_fixed")
    parser.add_argument("--gcs_bucket", default=None)
    parser.add_argument(
        "--gcs_prefix",
        default="dummy",
        help="Folder name inside the bucket to upload into, e.g. "
             "dummy_data_is_500 (matches the afs-poc-data folder naming "
             "convention already in use). Default: 'dummy'",
    )
    parser.add_argument(
        "--copies",
        type=int,
        default=None,
        help=f"How many copies of the full scenario set to generate "
             f"({LCM_RECORDS_PER_COPY} LCM obligations per copy). Default: 1.",
    )
    parser.add_argument(
        "--records_per_topic",
        type=int,
        default=None,
        help="Approximate number of LCM records wanted. Rounded UP to whole "
             "scenario sets, so the real count is a multiple of "
             f"{LCM_RECORDS_PER_COPY}. Ignored if --copies is given.",
    )
    args = parser.parse_args()

    if args.copies:
        copies = args.copies
    elif args.records_per_topic:
        copies = math.ceil(args.records_per_topic / LCM_RECORDS_PER_COPY)
    else:
        copies = 1

    topic_files = build_topics(copies)

    if args.gcs_bucket:
        from google.cloud import storage
        client = storage.Client()
        bucket = client.bucket(args.gcs_bucket)
        for name, records in topic_files.items():
            # Built manually (not os.path.join) so Windows doesn't insert backslashes.
            blob = bucket.blob(f"{args.gcs_prefix}/{name}.jsonl")
            body = "\n".join(json.dumps(r) for r in records)
            blob.upload_from_string(body)
            print(f"Uploaded gs://{args.gcs_bucket}/{args.gcs_prefix}/{name}.jsonl ({len(records)} records)")
        return

    os.makedirs(args.out_dir, exist_ok=True)
    for name, records in topic_files.items():
        path = os.path.join(args.out_dir, f"{name}.jsonl")
        with open(path, "w") as f:
            for r in records:
                f.write(json.dumps(r) + "\n")
        print(f"Wrote {path} ({len(records)} records)")


if __name__ == "__main__":
    run()
